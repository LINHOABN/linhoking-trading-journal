from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from app.config import settings
from app.database import Base, engine
from app.routers import auth, trades, tiers, stats, mt5, ws

# For a real deployment, replace this with Alembic migrations.
# This is fine for local dev / first deploy.
Base.metadata.create_all(bind=engine)

app = FastAPI(
    title="LINHOKING Trading Journal API",
    description="API pour le journal de trading XAU/USD intraday LINHOKING.",
    version="0.1.0",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.cors_origins_list,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(auth.router)
app.include_router(trades.router)
app.include_router(tiers.router)
app.include_router(stats.router)
app.include_router(mt5.router)
app.include_router(ws.router)


@app.get("/health")
def health():
    return {"status": "ok"}
