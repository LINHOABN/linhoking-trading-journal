from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from sqlalchemy import desc

from app.database import get_db
from app import models, schemas
from app.deps import get_current_user
from app.tier_engine import apply_trade_to_tier
from app.ws_manager import manager

router = APIRouter(prefix="/trades", tags=["trades"])


@router.get("", response_model=list[schemas.TradeOut])
def list_trades(
    limit: int = 100,
    current_user: models.User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    return (
        db.query(models.Trade)
        .filter(models.Trade.user_id == current_user.id)
        .order_by(desc(models.Trade.trade_date), desc(models.Trade.open_time))
        .limit(limit)
        .all()
    )


@router.post("", response_model=schemas.TradeOut, status_code=201)
async def create_trade(
    payload: schemas.TradeCreate,
    current_user: models.User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    trade = models.Trade(user_id=current_user.id, source="manual", **payload.model_dump())
    db.add(trade)

    tier = db.query(models.TierConfig).filter(models.TierConfig.user_id == current_user.id).first()
    if tier:
        apply_trade_to_tier(db, tier, trade.pnl)
        db.add(
            models.CapitalSnapshot(
                user_id=current_user.id,
                snapshot_date=trade.trade_date,
                capital=tier.current_capital,
                lot=tier.active_lot,
            )
        )

    db.commit()
    db.refresh(trade)

    await manager.send_to_user(
        current_user.id, {"type": "trade_created", "trade_id": trade.id, "pnl": trade.pnl}
    )
    return trade


@router.patch("/{trade_id}", response_model=schemas.TradeOut)
def update_trade(
    trade_id: str,
    payload: schemas.TradeUpdate,
    current_user: models.User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    trade = (
        db.query(models.Trade)
        .filter(models.Trade.id == trade_id, models.Trade.user_id == current_user.id)
        .first()
    )
    if not trade:
        raise HTTPException(status_code=404, detail="Trade introuvable")

    for field, value in payload.model_dump(exclude_unset=True).items():
        setattr(trade, field, value)

    db.commit()
    db.refresh(trade)
    return trade


@router.delete("/{trade_id}", status_code=204)
def delete_trade(
    trade_id: str,
    current_user: models.User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    trade = (
        db.query(models.Trade)
        .filter(models.Trade.id == trade_id, models.Trade.user_id == current_user.id)
        .first()
    )
    if not trade:
        raise HTTPException(status_code=404, detail="Trade introuvable")
    db.delete(trade)
    db.commit()
