from datetime import date, time, datetime
from typing import Literal, Optional
from pydantic import BaseModel, EmailStr, ConfigDict


# ---------- Auth ----------

class UserCreate(BaseModel):
    email: EmailStr
    password: str


class UserOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: str
    email: EmailStr
    mt5_api_key: str
    created_at: datetime


class Token(BaseModel):
    access_token: str
    token_type: str = "bearer"


# ---------- Trades ----------

class TradeBase(BaseModel):
    trade_date: date
    open_time: time
    close_time: time
    symbol: str = "XAUUSD"
    direction: Literal["BUY", "SELL"]
    volume: float
    entry_price: float
    exit_price: float
    stop_loss: float
    take_profit: float
    pnl: float
    emotion: Optional[str] = None
    strategy: Optional[str] = None
    mistake: Optional[str] = None
    note: Optional[str] = None
    screenshot_url: Optional[str] = None


class TradeCreate(TradeBase):
    pass


class TradeUpdate(BaseModel):
    emotion: Optional[str] = None
    strategy: Optional[str] = None
    mistake: Optional[str] = None
    note: Optional[str] = None
    screenshot_url: Optional[str] = None


class TradeOut(TradeBase):
    model_config = ConfigDict(from_attributes=True)
    id: str
    mt5_ticket: Optional[str] = None
    source: str
    created_at: datetime


# ---------- MT5 bridge ----------

class MT5TradePayload(BaseModel):
    """Payload sent by the MQL5 Expert Advisor when a position closes."""

    ticket: str
    symbol: str
    direction: Literal["BUY", "SELL"]
    volume: float
    entry_price: float
    exit_price: float
    stop_loss: float
    take_profit: float
    pnl: float
    open_time: datetime
    close_time: datetime


# ---------- Tier engine ----------

class TierOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    starting_capital: float
    current_capital: float
    active_lot: float
    current_risk: float
    next_objective: float
    step_down_threshold: float
    losses_before_step_down: int
    consecutive_losses: int


class TierUpdate(BaseModel):
    active_lot: Optional[float] = None
    current_risk: Optional[float] = None
    next_objective: Optional[float] = None
    step_down_threshold: Optional[float] = None
    losses_before_step_down: Optional[int] = None


# ---------- Stats ----------

class StatsSummary(BaseModel):
    win_rate: float
    total_trades: int
    avg_win: float
    avg_loss: float
    best_day: Optional[str] = None
    best_day_pnl: Optional[float] = None
    worst_day: Optional[str] = None
    worst_day_pnl: Optional[float] = None
    best_hour: Optional[str] = None


class CapitalPoint(BaseModel):
    date: date
    capital: float


class LotPoint(BaseModel):
    date: date
    lot: float
