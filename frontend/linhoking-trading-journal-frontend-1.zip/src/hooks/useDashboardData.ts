import { useCallback, useEffect, useState } from 'react'
import * as api from '../lib/api'
import { useLiveSocket } from './useLiveSocket'
import type { Trade, Tier, CapitalPoint, LotStep } from '../types'

interface DashboardData {
  trades: Trade[]
  tier: Tier | null
  startingCapital: number
  capitalCurve: CapitalPoint[]
  lotHistory: LotStep[]
  stats: api.StatsSummary | null
  loading: boolean
  error: string | null
  liveConnected: boolean
  refetch: () => void
}

export function useDashboardData(): DashboardData {
  const [trades, setTrades] = useState<Trade[]>([])
  const [tier, setTier] = useState<Tier | null>(null)
  const [startingCapital, setStartingCapital] = useState(0)
  const [capitalCurve, setCapitalCurve] = useState<CapitalPoint[]>([])
  const [lotHistory, setLotHistory] = useState<LotStep[]>([])
  const [stats, setStats] = useState<api.StatsSummary | null>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  const load = useCallback(async () => {
    try {
      const [tradesData, tierData, curveData, lotData, statsData] = await Promise.all([
        api.getTrades(),
        api.getTier(),
        api.getCapitalCurve(),
        api.getLotHistory(),
        api.getStatsSummary(),
      ])
      setTrades(tradesData)
      setTier(tierData.tier)
      setStartingCapital(tierData.startingCapital)
      setCapitalCurve(curveData)
      setLotHistory(lotData)
      setStats(statsData)
      setError(null)
    } catch (e) {
      setError(e instanceof api.ApiError ? e.message : 'Impossible de charger les données')
    } finally {
      setLoading(false)
    }
  }, [])

  useEffect(() => {
    load()
  }, [load])

  // Any live event (new trade, MT5 sync) simply triggers a refetch —
  // simpler and more robust than trying to patch state incrementally.
  const liveConnected = useLiveSocket(true, load)

  return {
    trades,
    tier,
    startingCapital,
    capitalCurve,
    lotHistory,
    stats,
    loading,
    error,
    liveConnected,
    refetch: load,
  }
}
