import type { LotStep } from '../types'

interface Props {
  data: LotStep[]
}

export default function LotHistoryChart({ data }: Props) {
  const maxLot = Math.max(...data.map((d) => d.lot))

  return (
    <div className="border border-graphite-700 dark:border-graphite-700 p-6">
      <div className="text-[10px] uppercase tracking-widest2 text-ink-500 dark:text-ink-300">
        Historique des lots
      </div>
      <div className="mt-5 flex h-[220px] items-end gap-3">
        {data.map((step) => (
          <div key={step.date} className="flex flex-1 flex-col items-center gap-2">
            <div className="w-full flex-1 flex items-end">
              <div
                className="w-full bg-signal-data/70"
                style={{ height: `${(step.lot / maxLot) * 100}%` }}
              />
            </div>
            <div className="font-mono text-[11px] text-ink-900 dark:text-paper-50">
              {step.lot.toFixed(2)}
            </div>
            <div className="font-mono text-[9px] text-ink-500 dark:text-ink-300">
              {step.date.slice(5)}
            </div>
          </div>
        ))}
        <div className="flex flex-1 flex-col items-center gap-2 opacity-40">
          <div className="w-full flex-1 flex items-end">
            <div className="w-full border border-dashed border-signal-data" style={{ height: '5%' }} />
          </div>
          <div className="font-mono text-[11px] text-ink-500 dark:text-ink-300">0.04</div>
          <div className="font-mono text-[9px] text-ink-500 dark:text-ink-300">objectif</div>
        </div>
      </div>
    </div>
  )
}
