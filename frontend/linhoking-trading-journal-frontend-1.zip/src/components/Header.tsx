import { Sun, Moon, Radio, LogOut } from 'lucide-react'
import { useTheme } from '../context/ThemeContext'
import { useAuth } from '../context/AuthContext'

interface Props {
  liveConnected: boolean
}

export default function Header({ liveConnected }: Props) {
  const { theme, toggle } = useTheme()
  const { user, logout } = useAuth()

  return (
    <header className="flex items-center justify-between border-b border-graphite-700/60 dark:border-graphite-700 px-6 py-4">
      <div className="flex items-center gap-3">
        <div className="flex h-8 w-8 items-center justify-center border border-ink-900 dark:border-paper-50 font-mono text-[13px] font-semibold text-ink-900 dark:text-paper-50">
          LK
        </div>
        <div className="leading-tight">
          <div className="font-mono text-[15px] font-semibold tracking-wide text-ink-900 dark:text-paper-50">
            LINHOKING
          </div>
          <div className="text-[10px] uppercase tracking-widest2 text-ink-500 dark:text-ink-300">
            Trading Journal
          </div>
        </div>
      </div>

      <div className="flex items-center gap-5">
        <div className="hidden items-center gap-2 border border-graphite-700 dark:border-graphite-700 px-2.5 py-1 text-[11px] font-mono text-ink-500 dark:text-ink-300 sm:flex">
          <Radio size={12} className={liveConnected ? 'text-signal-gain' : 'text-ink-500'} />
          {liveConnected ? 'Temps réel connecté' : 'Hors ligne'}
        </div>

        {user && (
          <span className="hidden font-mono text-[11px] text-ink-500 dark:text-ink-300 md:inline">
            {user.email}
          </span>
        )}

        <button
          onClick={toggle}
          aria-label="Changer de thème"
          className="flex h-8 w-8 items-center justify-center border border-graphite-700 text-ink-500 transition-colors hover:text-ink-900 dark:border-graphite-700 dark:text-ink-300 dark:hover:text-paper-50"
        >
          {theme === 'dark' ? <Sun size={14} /> : <Moon size={14} />}
        </button>

        <button
          onClick={logout}
          aria-label="Se déconnecter"
          className="flex h-8 w-8 items-center justify-center border border-graphite-700 text-ink-500 transition-colors hover:text-signal-loss dark:border-graphite-700 dark:text-ink-300"
        >
          <LogOut size={14} />
        </button>
      </div>
    </header>
  )
}
