import { AreaChart, Area, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid } from 'recharts'
import type { CapitalPoint } from '../types'
import { useTheme } from '../context/ThemeContext'

interface Props {
  data: CapitalPoint[]
}

export default function CapitalCurveChart({ data }: Props) {
  const { theme } = useTheme()
  const gridColor = theme === 'dark' ? '#262B33' : '#DDE1E6'
  const textColor = theme === 'dark' ? '#8B92A0' : '#5B6470'

  return (
    <div className="border border-graphite-700 dark:border-graphite-700 p-6">
      <div className="text-[10px] uppercase tracking-widest2 text-ink-500 dark:text-ink-300">
        Courbe de capital
      </div>
      <div className="mt-4 h-[220px]">
        <ResponsiveContainer width="100%" height="100%">
          <AreaChart data={data} margin={{ top: 4, right: 8, left: -16, bottom: 0 }}>
            <defs>
              <linearGradient id="capitalFill" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor="#5B8DEF" stopOpacity={0.25} />
                <stop offset="100%" stopColor="#5B8DEF" stopOpacity={0} />
              </linearGradient>
            </defs>
            <CartesianGrid strokeDasharray="1 0" stroke={gridColor} vertical={false} />
            <XAxis
              dataKey="date"
              tickFormatter={(d: string) => d.slice(5)}
              tick={{ fontSize: 10, fill: textColor, fontFamily: 'IBM Plex Mono' }}
              axisLine={{ stroke: gridColor }}
              tickLine={false}
            />
            <YAxis
              tick={{ fontSize: 10, fill: textColor, fontFamily: 'IBM Plex Mono' }}
              axisLine={false}
              tickLine={false}
              width={44}
              domain={['dataMin - 15', 'dataMax + 15']}
            />
            <Tooltip
              contentStyle={{
                background: theme === 'dark' ? '#14171D' : '#FFFFFF',
                border: `1px solid ${gridColor}`,
                borderRadius: 2,
                fontSize: 12,
                fontFamily: 'IBM Plex Mono',
              }}
              labelStyle={{ color: textColor }}
              formatter={(value: number) => [`${value.toFixed(2)} $`, 'Capital']}
            />
            <Area
              type="monotone"
              dataKey="capital"
              stroke="#5B8DEF"
              strokeWidth={1.5}
              fill="url(#capitalFill)"
            />
          </AreaChart>
        </ResponsiveContainer>
      </div>
    </div>
  )
}
