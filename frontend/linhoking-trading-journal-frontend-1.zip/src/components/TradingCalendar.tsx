import { useMemo } from 'react'
import type { Trade } from '../types'

interface Props {
  trades: Trade[]
  year: number
  month: number // 0-indexed
}

export default function TradingCalendar({ trades, year, month }: Props) {
  const dayMap = useMemo(() => {
    const map = new Map<string, { pnl: number; count: number }>()
    for (const t of trades) {
      const existing = map.get(t.date) ?? { pnl: 0, count: 0 }
      existing.pnl += t.pnl
      existing.count += 1
      map.set(t.date, existing)
    }
    return map
  }, [trades])

  const firstDay = new Date(year, month, 1)
  const daysInMonth = new Date(year, month + 1, 0).getDate()
  const startWeekday = (firstDay.getDay() + 6) % 7 // Monday-first

  const cells: (number | null)[] = [
    ...Array(startWeekday).fill(null),
    ...Array.from({ length: daysInMonth }, (_, i) => i + 1),
  ]

  const monthLabel = firstDay.toLocaleDateString('fr-FR', { month: 'long', year: 'numeric' })
  const weekdays = ['Lun', 'Mar', 'Mer', 'Jeu', 'Ven', 'Sam', 'Dim']

  return (
    <div className="border border-graphite-700 dark:border-graphite-700 p-6">
      <div className="flex items-center justify-between">
        <div className="text-[10px] uppercase tracking-widest2 text-ink-500 dark:text-ink-300">
          Calendrier — {monthLabel}
        </div>
      </div>

      <div className="mt-4 grid grid-cols-7 gap-px bg-graphite-700">
        {weekdays.map((w) => (
          <div
            key={w}
            className="bg-paper-50 dark:bg-graphite-900 py-1.5 text-center font-mono text-[10px] text-ink-500 dark:text-ink-300"
          >
            {w}
          </div>
        ))}

        {cells.map((day, idx) => {
          if (day === null) {
            return <div key={idx} className="bg-paper-50 dark:bg-graphite-900 aspect-square" />
          }
          const dateKey = `${year}-${String(month + 1).padStart(2, '0')}-${String(day).padStart(2, '0')}`
          const entry = dayMap.get(dateKey)
          const isWin = entry && entry.pnl >= 0
          const isLoss = entry && entry.pnl < 0

          return (
            <div
              key={idx}
              className={`aspect-square bg-paper-50 dark:bg-graphite-900 p-1.5 ${
                isWin ? 'bg-signal-gain/10' : isLoss ? 'bg-signal-loss/10' : ''
              }`}
            >
              <div className="font-mono text-[10px] text-ink-500 dark:text-ink-300">{day}</div>
              {entry && (
                <div
                  className={`mt-1 font-mono text-[11px] font-semibold ${
                    isWin ? 'text-signal-gain' : 'text-signal-loss'
                  }`}
                >
                  {isWin ? '+' : ''}
                  {entry.pnl.toFixed(0)} $
                </div>
              )}
            </div>
          )
        })}
      </div>
    </div>
  )
}
