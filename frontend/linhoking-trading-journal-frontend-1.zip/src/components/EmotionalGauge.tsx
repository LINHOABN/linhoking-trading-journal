import type { AccountZone, Tier } from '../types'

interface Props {
  tier: Tier
}

function getZone(tier: Tier): { zone: AccountZone; label: string; detail: string } {
  const bufferAboveThreshold = tier.currentCapital - tier.stepDownThreshold
  const distanceToObjective = tier.nextObjective - tier.currentCapital
  const bufferRatio = bufferAboveThreshold / (tier.currentCapital - tier.stepDownThreshold + distanceToObjective)

  if (bufferAboveThreshold <= tier.currentRisk * 1.5) {
    return {
      zone: 'red',
      label: 'Zone rouge',
      detail: 'Risque important de retour au palier inférieur.',
    }
  }
  if (bufferRatio < 0.35) {
    return {
      zone: 'orange',
      label: 'Zone orange',
      detail: 'Approche d\u2019un niveau dangereux — vigilance sur le risque.',
    }
  }
  return {
    zone: 'green',
    label: 'Zone verte',
    detail: 'Compte en progression saine vers l\u2019objectif.',
  }
}

const zoneStyles: Record<AccountZone, string> = {
  green: 'bg-signal-gain',
  orange: 'bg-signal-warn',
  red: 'bg-signal-loss',
}

export default function EmotionalGauge({ tier }: Props) {
  const { zone, label, detail } = getZone(tier)

  return (
    <div className="border border-graphite-700 dark:border-graphite-700 p-6">
      <div className="text-[10px] uppercase tracking-widest2 text-ink-500 dark:text-ink-300">
        État du compte
      </div>

      <div className="mt-3 flex items-center gap-2">
        <span className={`h-2.5 w-2.5 ${zoneStyles[zone]}`} />
        <span className="font-mono text-[14px] font-semibold text-ink-900 dark:text-paper-50">
          {label}
        </span>
      </div>

      <p className="mt-2 text-[12px] leading-relaxed text-ink-500 dark:text-ink-300">{detail}</p>

      <div className="relative mt-4 h-1.5 w-full border border-graphite-700">
        <div className="flex h-full w-full">
          <div className="h-full flex-1 bg-signal-loss/30" />
          <div className="h-full flex-1 bg-signal-warn/30" />
          <div className="h-full flex-1 bg-signal-gain/30" />
        </div>
        <div
          className={`absolute top-1/2 h-3.5 w-0.5 -translate-y-1/2 ${zoneStyles[zone]}`}
          style={{ left: zone === 'red' ? '15%' : zone === 'orange' ? '48%' : '80%' }}
        />
      </div>
    </div>
  )
}
