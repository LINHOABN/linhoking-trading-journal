import { LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid, Legend } from 'recharts'
import type { CapitalPoint } from '../types'
import { useTheme } from '../context/ThemeContext'

interface Props {
  data: CapitalPoint[]
}

// Risk modeled as ~1.5% of capital per trade, consistent with the tier engine
export default function RiskEvolutionChart({ data }: Props) {
  const { theme } = useTheme()
  const gridColor = theme === 'dark' ? '#262B33' : '#DDE1E6'
  const textColor = theme === 'dark' ? '#8B92A0' : '#5B6470'

  const chartData = data.map((d) => ({ date: d.date, capital: d.capital, risque: +(d.capital * 0.045).toFixed(2) }))

  return (
    <div className="border border-graphite-700 dark:border-graphite-700 p-6">
      <div className="text-[10px] uppercase tracking-widest2 text-ink-500 dark:text-ink-300">
        Évolution du risque
      </div>
      <div className="mt-4 h-[220px]">
        <ResponsiveContainer width="100%" height="100%">
          <LineChart data={chartData} margin={{ top: 4, right: 8, left: -16, bottom: 0 }}>
            <CartesianGrid strokeDasharray="1 0" stroke={gridColor} vertical={false} />
            <XAxis
              dataKey="date"
              tickFormatter={(d: string) => d.slice(5)}
              tick={{ fontSize: 10, fill: textColor, fontFamily: 'IBM Plex Mono' }}
              axisLine={{ stroke: gridColor }}
              tickLine={false}
            />
            <YAxis
              tick={{ fontSize: 10, fill: textColor, fontFamily: 'IBM Plex Mono' }}
              axisLine={false}
              tickLine={false}
              width={40}
            />
            <Tooltip
              contentStyle={{
                background: theme === 'dark' ? '#14171D' : '#FFFFFF',
                border: `1px solid ${gridColor}`,
                borderRadius: 2,
                fontSize: 12,
                fontFamily: 'IBM Plex Mono',
              }}
            />
            <Legend
              wrapperStyle={{ fontSize: 10, fontFamily: 'IBM Plex Mono', color: textColor }}
            />
            <Line type="monotone" dataKey="capital" name="Capital" stroke="#5B8DEF" strokeWidth={1.5} dot={false} />
            <Line type="monotone" dataKey="risque" name="Risque / trade" stroke="#D89614" strokeWidth={1.5} dot={false} />
          </LineChart>
        </ResponsiveContainer>
      </div>
    </div>
  )
}
