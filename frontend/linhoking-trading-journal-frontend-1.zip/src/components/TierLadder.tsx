import type { Tier } from '../types'

interface Props {
  tier: Tier
}

export default function TierLadder({ tier }: Props) {
  const distanceToObjective = tier.nextObjective - tier.currentCapital
  const distanceAboveThreshold = tier.currentCapital - tier.stepDownThreshold
  const totalSpan = tier.nextObjective - tier.stepDownThreshold
  const positionPct = Math.min(
    100,
    Math.max(0, (distanceAboveThreshold / totalSpan) * 100)
  )

  return (
    <div className="border border-graphite-700 dark:border-graphite-700 p-6 md:col-span-2">
      <div className="flex items-center justify-between">
        <div className="text-[10px] uppercase tracking-widest2 text-ink-500 dark:text-ink-300">
          Moteur de paliers
        </div>
        <div className="font-mono text-[11px] text-ink-500 dark:text-ink-300">
          Lot actif <span className="text-ink-900 dark:text-paper-50">{tier.activeLot.toFixed(2)}</span>
        </div>
      </div>

      {/* Ladder track */}
      <div className="relative mt-6 h-10">
        <div className="absolute left-0 right-0 top-1/2 h-px -translate-y-1/2 bg-graphite-700" />

        {/* tick marks */}
        {Array.from({ length: 11 }).map((_, i) => (
          <div
            key={i}
            className="absolute top-1/2 h-2 w-px -translate-y-1/2 bg-graphite-700"
            style={{ left: `${i * 10}%` }}
          />
        ))}

        {/* threshold marker */}
        <div className="absolute -top-1 flex flex-col items-center" style={{ left: '0%' }}>
          <span className="font-mono text-[10px] text-signal-loss">{tier.stepDownThreshold} $</span>
        </div>

        {/* objective marker */}
        <div className="absolute -top-1 right-0 flex flex-col items-center">
          <span className="font-mono text-[10px] text-signal-gain">{tier.nextObjective} $</span>
        </div>

        {/* current position marker */}
        <div
          className="absolute top-1/2 -translate-x-1/2 -translate-y-1/2"
          style={{ left: `${positionPct}%` }}
        >
          <div className="h-3.5 w-3.5 rotate-45 border border-ink-900 bg-paper-50 dark:border-paper-50 dark:bg-graphite-900" />
        </div>
      </div>

      <div className="mt-5 grid grid-cols-2 gap-x-6 gap-y-3 sm:grid-cols-4">
        <Metric label="Capital actuel" value={`${tier.currentCapital.toFixed(2)} $`} emphasis />
        <Metric label="Risque" value={`${tier.currentRisk.toFixed(2)} $`} />
        <Metric label="Distance objectif" value={`${distanceToObjective.toFixed(2)} $`} />
        <Metric
          label="Protection"
          value={`${tier.lossesBeforeStepDown} pertes`}
          hint="avant retour au lot inférieur"
        />
      </div>
    </div>
  )
}

function Metric({
  label,
  value,
  hint,
  emphasis,
}: {
  label: string
  value: string
  hint?: string
  emphasis?: boolean
}) {
  return (
    <div>
      <div className="text-[10px] uppercase tracking-widest2 text-ink-500 dark:text-ink-300">
        {label}
      </div>
      <div
        className={`mt-1 font-mono text-[15px] ${
          emphasis ? 'font-semibold text-ink-900 dark:text-paper-50' : 'text-ink-900 dark:text-paper-50'
        }`}
      >
        {value}
      </div>
      {hint && <div className="mt-0.5 text-[10px] text-ink-500 dark:text-ink-300">{hint}</div>}
    </div>
  )
}
