import { ArrowUpRight, ArrowDownRight } from 'lucide-react'
import type { CapitalPoint } from '../types'

interface Props {
  curve: CapitalPoint[]
  startingCapital: number
}

export default function CapitalHero({ curve, startingCapital }: Props) {
  const current = curve[curve.length - 1].capital
  const previous = curve.length > 1 ? curve[curve.length - 2].capital : startingCapital
  const changeFromStart = ((current - startingCapital) / startingCapital) * 100
  const dayChange = current - previous
  const isPositive = changeFromStart >= 0

  return (
    <div className="border border-graphite-700 dark:border-graphite-700 p-6">
      <div className="text-[10px] uppercase tracking-widest2 text-ink-500 dark:text-ink-300">
        Capital
      </div>
      <div className="mt-2 flex items-baseline gap-3">
        <span className="font-mono text-[42px] font-semibold leading-none text-ink-900 dark:text-paper-50">
          {current.toFixed(2)}
        </span>
        <span className="font-mono text-[16px] text-ink-500 dark:text-ink-300">USD</span>
      </div>

      <div className="mt-3 flex items-center gap-4">
        <div
          className={`flex items-center gap-1 font-mono text-[13px] font-medium ${
            isPositive ? 'text-signal-gain' : 'text-signal-loss'
          }`}
        >
          {isPositive ? <ArrowUpRight size={14} /> : <ArrowDownRight size={14} />}
          {isPositive ? '+' : ''}
          {changeFromStart.toFixed(1)}%
        </div>
        <div className="font-mono text-[12px] text-ink-500 dark:text-ink-300">
          {dayChange >= 0 ? '+' : ''}
          {dayChange.toFixed(2)} $ vs. dernière séance
        </div>
        <div className="font-mono text-[12px] text-ink-500 dark:text-ink-300">
          Départ : {startingCapital.toFixed(2)} $
        </div>
      </div>
    </div>
  )
}
