import { ImageOff } from 'lucide-react'
import type { Trade } from '../types'

interface Props {
  trades: Trade[]
}

export default function TradeJournal({ trades }: Props) {
  return (
    <div className="border border-graphite-700 dark:border-graphite-700">
      <div className="border-b border-graphite-700 dark:border-graphite-700 px-6 py-4">
        <div className="text-[10px] uppercase tracking-widest2 text-ink-500 dark:text-ink-300">
          Journal des trades
        </div>
      </div>

      <div className="divide-y divide-graphite-700 dark:divide-graphite-700">
        {trades.map((t) => (
          <TradeRow key={t.id} trade={t} />
        ))}
      </div>
    </div>
  )
}

function TradeRow({ trade }: { trade: Trade }) {
  const isWin = trade.pnl >= 0

  return (
    <div className="grid grid-cols-1 gap-4 px-6 py-4 md:grid-cols-[110px_1fr_auto]">
      <div className="font-mono text-[11px] text-ink-500 dark:text-ink-300">
        <div>{trade.date}</div>
        <div>
          {trade.openTime}–{trade.closeTime}
        </div>
      </div>

      <div>
        <div className="flex flex-wrap items-center gap-2">
          <span className="font-mono text-[13px] font-semibold text-ink-900 dark:text-paper-50">
            {trade.symbol}
          </span>
          <span
            className={`px-1.5 py-0.5 font-mono text-[10px] font-semibold ${
              trade.direction === 'BUY'
                ? 'bg-signal-gain/15 text-signal-gain'
                : 'bg-signal-loss/15 text-signal-loss'
            }`}
          >
            {trade.direction}
          </span>
          <span className="font-mono text-[11px] text-ink-500 dark:text-ink-300">
            {trade.volume.toFixed(2)} lot
          </span>
        </div>

        <div className="mt-1.5 font-mono text-[11px] text-ink-500 dark:text-ink-300">
          Entrée {trade.entryPrice} · Sortie {trade.exitPrice} · SL {trade.stopLoss} · TP {trade.takeProfit}
        </div>

        <p className="mt-2 text-[12px] leading-relaxed text-ink-500 dark:text-ink-300">
          <span className="text-ink-900 dark:text-paper-50">{trade.strategy}.</span> {trade.note}
        </p>

        {trade.mistake && (
          <div className="mt-1.5 text-[11px] text-signal-warn">Erreur notée · {trade.mistake}</div>
        )}

        <div className="mt-2 flex items-center gap-3 text-[10px] uppercase tracking-widest2 text-ink-500 dark:text-ink-300">
          <span>Émotion · {trade.emotion}</span>
          {!trade.screenshotUrl && (
            <span className="flex items-center gap-1 normal-case tracking-normal opacity-60">
              <ImageOff size={11} /> pas de capture
            </span>
          )}
        </div>
      </div>

      <div className="flex items-start justify-start md:justify-end">
        <span
          className={`font-mono text-[16px] font-semibold ${
            isWin ? 'text-signal-gain' : 'text-signal-loss'
          }`}
        >
          {isWin ? '+' : ''}
          {trade.pnl.toFixed(2)} $
        </span>
      </div>
    </div>
  )
}
