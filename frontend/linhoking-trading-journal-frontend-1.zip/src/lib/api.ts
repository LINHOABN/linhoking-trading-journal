import type { Trade, Tier, CapitalPoint, LotStep, Direction, Emotion } from '../types'

const API_URL = import.meta.env.VITE_API_URL || 'http://localhost:8000'
const TOKEN_KEY = 'linhoking_token'

export function getToken(): string | null {
  return localStorage.getItem(TOKEN_KEY)
}

export function setToken(token: string) {
  localStorage.setItem(TOKEN_KEY, token)
}

export function clearToken() {
  localStorage.removeItem(TOKEN_KEY)
}

export function wsUrl(): string {
  const base = API_URL.replace(/^http/, 'ws')
  const token = getToken()
  return `${base}/ws/live?token=${encodeURIComponent(token ?? '')}`
}

class ApiError extends Error {
  status: number
  constructor(status: number, message: string) {
    super(message)
    this.status = status
  }
}

async function request<T>(path: string, options: RequestInit = {}): Promise<T> {
  const token = getToken()
  const headers: Record<string, string> = {
    'Content-Type': 'application/json',
    ...(options.headers as Record<string, string> | undefined),
  }
  if (token) headers['Authorization'] = `Bearer ${token}`

  const res = await fetch(`${API_URL}${path}`, { ...options, headers })

  if (!res.ok) {
    let detail = res.statusText
    try {
      const body = await res.json()
      detail = body.detail ?? detail
    } catch {
      /* no JSON body */
    }
    throw new ApiError(res.status, detail)
  }

  if (res.status === 204) return undefined as T
  return res.json() as Promise<T>
}

// ---------- Auth ----------

export async function login(email: string, password: string): Promise<string> {
  // FastAPI's OAuth2PasswordRequestForm expects x-www-form-urlencoded, not JSON
  const body = new URLSearchParams({ username: email, password })
  const res = await fetch(`${API_URL}/auth/login`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body,
  })
  if (!res.ok) {
    const err = await res.json().catch(() => ({ detail: 'Échec de la connexion' }))
    throw new ApiError(res.status, err.detail ?? 'Échec de la connexion')
  }
  const data = await res.json()
  return data.access_token as string
}

export async function register(email: string, password: string): Promise<void> {
  await request('/auth/register', {
    method: 'POST',
    body: JSON.stringify({ email, password }),
  })
}

export interface Me {
  id: string
  email: string
  mt5ApiKey: string
}

export async function getMe(): Promise<Me> {
  const data = await request<{ id: string; email: string; mt5_api_key: string }>('/auth/me')
  return { id: data.id, email: data.email, mt5ApiKey: data.mt5_api_key }
}

// ---------- Trades ----------

interface ApiTrade {
  id: string
  trade_date: string
  open_time: string
  close_time: string
  symbol: string
  direction: Direction
  volume: number
  entry_price: number
  exit_price: number
  stop_loss: number
  take_profit: number
  pnl: number
  emotion: string | null
  strategy: string | null
  mistake: string | null
  note: string | null
  screenshot_url: string | null
  mt5_ticket: string | null
  source: string
}

function mapTrade(t: ApiTrade): Trade {
  return {
    id: t.id,
    date: t.trade_date,
    openTime: t.open_time.slice(0, 5),
    closeTime: t.close_time.slice(0, 5),
    symbol: t.symbol,
    direction: t.direction,
    volume: t.volume,
    entryPrice: t.entry_price,
    exitPrice: t.exit_price,
    stopLoss: t.stop_loss,
    takeProfit: t.take_profit,
    pnl: t.pnl,
    emotion: (t.emotion as Emotion) ?? 'neutre',
    strategy: t.strategy ?? '',
    mistake: t.mistake,
    note: t.note ?? '',
    screenshotUrl: t.screenshot_url,
  }
}

export async function getTrades(): Promise<Trade[]> {
  const data = await request<ApiTrade[]>('/trades')
  return data.map(mapTrade)
}

export interface NewTradeInput {
  date: string
  openTime: string
  closeTime: string
  symbol: string
  direction: Direction
  volume: number
  entryPrice: number
  exitPrice: number
  stopLoss: number
  takeProfit: number
  pnl: number
  emotion?: string
  strategy?: string
  mistake?: string
  note?: string
  screenshotUrl?: string
}

export async function createTrade(input: NewTradeInput): Promise<Trade> {
  const data = await request<ApiTrade>('/trades', {
    method: 'POST',
    body: JSON.stringify({
      trade_date: input.date,
      open_time: input.openTime,
      close_time: input.closeTime,
      symbol: input.symbol,
      direction: input.direction,
      volume: input.volume,
      entry_price: input.entryPrice,
      exit_price: input.exitPrice,
      stop_loss: input.stopLoss,
      take_profit: input.takeProfit,
      pnl: input.pnl,
      emotion: input.emotion,
      strategy: input.strategy,
      mistake: input.mistake,
      note: input.note,
      screenshot_url: input.screenshotUrl,
    }),
  })
  return mapTrade(data)
}

// ---------- Tier engine ----------

interface ApiTier {
  starting_capital: number
  current_capital: number
  active_lot: number
  current_risk: number
  next_objective: number
  step_down_threshold: number
  losses_before_step_down: number
  consecutive_losses: number
}

function mapTier(t: ApiTier): Tier {
  return {
    currentCapital: t.current_capital,
    activeLot: t.active_lot,
    currentRisk: t.current_risk,
    nextObjective: t.next_objective,
    lossesBeforeStepDown: t.losses_before_step_down,
    stepDownThreshold: t.step_down_threshold,
  }
}

export async function getTier(): Promise<{ tier: Tier; startingCapital: number }> {
  const data = await request<ApiTier>('/tiers/me')
  return { tier: mapTier(data), startingCapital: data.starting_capital }
}

// ---------- Stats ----------

export interface StatsSummary {
  winRate: number
  totalTrades: number
  avgWin: number
  avgLoss: number
  bestDay: string | null
  bestDayPnl: number | null
  worstDay: string | null
  worstDayPnl: number | null
  bestHour: string | null
}

export async function getStatsSummary(): Promise<StatsSummary> {
  const data = await request<{
    win_rate: number
    total_trades: number
    avg_win: number
    avg_loss: number
    best_day: string | null
    best_day_pnl: number | null
    worst_day: string | null
    worst_day_pnl: number | null
    best_hour: string | null
  }>('/stats/summary')
  return {
    winRate: data.win_rate,
    totalTrades: data.total_trades,
    avgWin: data.avg_win,
    avgLoss: data.avg_loss,
    bestDay: data.best_day,
    bestDayPnl: data.best_day_pnl,
    worstDay: data.worst_day,
    worstDayPnl: data.worst_day_pnl,
    bestHour: data.best_hour,
  }
}

export async function getCapitalCurve(): Promise<CapitalPoint[]> {
  return request<CapitalPoint[]>('/stats/capital-curve')
}

export async function getLotHistory(): Promise<LotStep[]> {
  return request<LotStep[]>('/stats/lot-history')
}

export { ApiError }
